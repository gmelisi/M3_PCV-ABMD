pmemd.cuda -O -i pcv-abmd.in -o abmd_001.out -p M2_TIO.prmtop -c init.rst7 -r abmd_001.rst7 -x abmd_001.nc -inf abmd_001.info
